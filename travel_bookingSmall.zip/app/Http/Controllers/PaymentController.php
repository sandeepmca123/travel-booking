<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Razorpay\Api\Api;
use App\Models\Payment;

class PaymentController extends Controller
{

    public function createOrder(Request $request)
    {

        $amount = $request->amount;

        $api = new Api(config('services.razorpay.key'), config('services.razorpay.secret'));

        $order = $api->order->create([
            'receipt' => 'order_rcptid_' . time(),
            'amount' => $amount * 100,
            'currency' => 'INR'
        ]);

        return response()->json([
            'order_id' => $order['id'],
            'amount' => $amount,
            'key' => config('services.razorpay.key')
        ]);
    }


    public function verifyPayment(Request $request)
{

    $api = new Api(config('services.razorpay.key'), config('services.razorpay.secret'));

    try {

        $attributes = [
            'razorpay_order_id' => $request->razorpay_order_id,
            'razorpay_payment_id' => $request->razorpay_payment_id,
            'razorpay_signature' => $request->razorpay_signature
        ];

        $api->utility->verifyPaymentSignature($attributes);

        Payment::create([
        'tour_id' => $request->tour_id,
        'razorpay_payment_id' => $request->razorpay_payment_id,
        'razorpay_order_id' => $request->razorpay_order_id,
        'razorpay_signature' => $request->razorpay_signature,
        'amount' => $request->amount,
        'status' => 'success',
        'payment_method' => $request->payment_method ?? 'N/A', 
    ]);
        return response()->json([
            'status' => 'success',
            'redirect' => route('tour.booking.success',$request->razorpay_order_id)
        ]);

    } catch (\Exception $e) {

        return response()->json([
            'status' => 'failed'
        ]);
    }

}

    }
    
    

