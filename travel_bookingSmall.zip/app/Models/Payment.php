<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

   class Payment extends Model
{
    protected $fillable = [
        'tour_id',
        'razorpay_payment_id',
        'razorpay_order_id',
        'razorpay_signature',
        'amount',
        'status'
    ];


    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    protected static function boot()
{
    parent::boot();

    static::creating(function ($payment) {
        $lastPayment = Payment::orderBy('id','desc')->first();
        if ($lastPayment && $lastPayment->booking_id) {
            $lastNumber = (int) str_replace('BS-', '', $lastPayment->booking_id);
            $payment->booking_id = 'BS-' . ($lastNumber + 1);
        } else {
            $payment->booking_id = 'BS-1001';
        }
    });
}

}
