@extends('layouts.admin')
@section('content')

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <h2 class="fw-bold mb-2">Add Package</h2>
        <a href="{{ route('admin.packages.index') }}" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Back to Packages
        </a>
    </div>

    <div class="card shadow-sm rounded-4 border-0">
        <div class="card-body">
            <form id="packageForm" action="{{ route('admin.packages.store') }}" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                @csrf

                <div class="mb-3">
                    <label class="form-label fw-semibold">Package Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control rounded-3 shadow-sm" value="{{ old('name') }}" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Package Type <span class="text-danger">*</span></label>
                    <select name="type" id="packageType" class="form-select rounded-3 shadow-sm" required>
                        <option value="hotel" {{ old('type')=='hotel' ? 'selected' : '' }}>Hotel</option>
                        <option value="tour" {{ old('type')=='tour' ? 'selected' : '' }}>Tour</option>
                        <option value="combo" {{ old('type')=='combo' ? 'selected' : '' }}>Combo</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Package Image</label>
                    <input type="file" name="image" class="form-control rounded-3 shadow-sm" accept="image/*">
                    <small class="text-muted">JPG, PNG, WEBP allowed</small>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Gallery Images</label>
                    <input type="file" name="gallery[]" class="form-control rounded-3 shadow-sm" accept="image/*" multiple>
                    <small class="text-muted">You can upload multiple images (JPG, PNG, WEBP)</small>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Slug <span class="text-danger">*</span></label>
                    <input type="text" name="slug" class="form-control rounded-3 shadow-sm" value="{{ old('slug') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Price <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" name="price" class="form-control rounded-3 shadow-sm" value="{{ old('price') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Duration</label>
                    <input type="text" id="duration" name="duration" class="form-control rounded-3 shadow-sm" value="{{ old('duration') }}" placeholder="e.g. 5 Days / 4 Nights" pattern="^\d+\s*Days\s*/\s*\d+\s*Nights$">
                    <small class="text-muted">Format: X Days / Y Nights</small>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Short Description</label>
                    <textarea name="short_description" class="form-control rounded-3 shadow-sm">{{ old('short_description') }}</textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Description</label>
                    <textarea name="description" class="form-control rounded-3 shadow-sm" rows="4">{{ old('description') }}</textarea>
                </div>

                <div id="roomsSection" class="mb-3">
                    <label class="form-label fw-semibold">Select Rooms</label>
                    @foreach($rooms as $room)
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="rooms[]" value="{{ $room->id }}"
                                {{ is_array(old('rooms')) && in_array($room->id, old('rooms')) ? 'checked' : '' }}>
                            <label class="form-check-label">{{ $room->name }} (Hotel: {{ $room->property->name }})</label>
                        </div>
                    @endforeach
                </div>

                <div id="toursSection" class="mb-3">
                    <label class="form-label fw-semibold">Select Tours</label>
                    @foreach($tours as $tour)
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="tours[]" value="{{ $tour->id }}"
                                {{ is_array(old('tours')) && in_array($tour->id, old('tours')) ? 'checked' : '' }}>
                            <label class="form-check-label">{{ $tour->name }} ({{ $tour->location }})</label>
                        </div>
                    @endforeach
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Package Visibility</label>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="popular" id="popular" value="1" {{ old('popular') ? 'checked' : '' }}>
                        <label class="form-check-label fw-medium" for="popular">Mark as Popular Package</label>
                    </div>
                    <small class="text-muted"> Enable this if you want to show this package in the <b>Popular Packages</b> section. </small>
                </div>

                <div class="d-flex justify-content-end mt-4">
                    <button type="submit" class="btn btn-success btn-lg rounded-3 shadow-sm">
                        <i class="bi bi-check-circle me-1"></i> Save
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<script>
    document.getElementById('duration').addEventListener('blur', function() {
        const val = this.value.trim();
        const pattern = /^\d+\s*Days\s*\/\s*\d+\s*Nights$/i;
        if (val !== "" && !pattern.test(val)) {
            alert("Please enter duration in format: X Days / Y Nights");
            this.focus();
        }
    });

    function toggleSections() {
        const type = document.getElementById('packageType').value;
        document.getElementById('roomsSection').style.display = (type === 'hotel' || type === 'combo') ? 'block' : 'none';
        document.getElementById('toursSection').style.display = (type === 'tour' || type === 'combo') ? 'block' : 'none';
    }

    document.getElementById('packageType').addEventListener('change', toggleSections);
    window.addEventListener('DOMContentLoaded', toggleSections);
</script>
<script>
$(document).ready(function () {

    // Custom method for duration
    $.validator.addMethod("durationFormat", function(value, element) {
        if (value === "") return true; // optional
        return /^\d+\s*Days\s*\/\s*\d+\s*Nights$/i.test(value);
    }, "Please enter duration in format: X Days / Y Nights");

    $("#packageForm").validate({
        errorClass: "is-invalid",
        validClass: "is-valid",
        errorElement: "div",

        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            element.closest(".mb-3").append(error);
        },

        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },

        unhighlight: function (element) {
            $(element).removeClass("is-invalid").addClass("is-valid");
        },

        rules: {
            name: {
                required: true,
                minlength: 2,
                maxlength: 255
            },
            type: {
                required: true
            },
            slug: {
                required: true,
                minlength: 2,
                maxlength: 255
            },
            price: {
                required: true,
                number: true,
                min: 0
            },
            duration: {
                required: true,
                durationFormat: true
            },
            'rooms[]': {
                required: function() {
                    const type = $('#packageType').val();
                    return type === 'hotel' || type === 'combo';
                }
            },
            'tours[]': {
                required: function() {
                    const type = $('#packageType').val();
                    return type === 'tour' || type === 'combo';
                }
            }
        },

        messages: {
            name: {
                required: "Please enter package name",
                minlength: "Package name must be at least 2 characters",
                maxlength: "Package name cannot exceed 255 characters"
            },
            type: {
                required: "Please select package type"
            },
            slug: {
                required: "Please enter slug",
                minlength: "Slug must be at least 2 characters",
                maxlength: "Slug cannot exceed 255 characters"
            },
            price: {
                required: "Please enter price",
                number: "Enter a valid number",
                min: "Price cannot be negative"
            },
            'rooms[]': {
                required: "Please select at least one room"
            },
            'tours[]': {
                required: "Please select at least one tour"
            }
        },

        submitHandler: function(form) {
            $('button[type="submit"]').prop('disabled', true);
            form.submit();
        }
    });

});
</script>
@endsection
